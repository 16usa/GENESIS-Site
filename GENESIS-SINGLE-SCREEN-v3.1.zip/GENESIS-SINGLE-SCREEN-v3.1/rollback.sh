#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
LATEST="$(ls -1dt "$ROOT"/.genesis-backups/GENESIS-SINGLE-SCREEN-v3.1-* 2>/dev/null | head -n 1 || true)"
if [ -z "$LATEST" ]; then
  echo "No GENESIS-SINGLE-SCREEN-v3.1 backup found."
  exit 1
fi
for target in ".conversation/public" "artifacts/api-server/genesis/public"; do
  if [ -d "$LATEST/$target" ] && [ -d "$ROOT/$target" ]; then
    cp "$LATEST/$target"/* "$ROOT/$target"/
  fi
done
echo "Rollback completed from: $LATEST"
echo "No server restart was performed."
