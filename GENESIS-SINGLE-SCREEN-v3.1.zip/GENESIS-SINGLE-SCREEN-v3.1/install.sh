#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_ROOT="$ROOT/.genesis-backups/GENESIS-SINGLE-SCREEN-v3.1-$STAMP"
SRC_PUBLIC="$PATCH_DIR/public"
UPDATED=0

mkdir -p "$BACKUP_ROOT"

restore_conversation_if_missing() {
  if [ ! -d "$ROOT/.conversation/public" ] && [ -d "$ROOT/artifacts/api-server/genesis" ]; then
    rm -rf "$ROOT/.conversation"
    cp -a "$ROOT/artifacts/api-server/genesis" "$ROOT/.conversation"
  fi
}

copy_into_target() {
  local target_public="$1"
  local marker_dir
  marker_dir="${target_public#$ROOT/}"
  mkdir -p "$BACKUP_ROOT/$marker_dir"

  for file in index.html styles.css app.js; do
    if [ -f "$target_public/$file" ]; then
      cp "$target_public/$file" "$BACKUP_ROOT/$marker_dir/$file"
    fi
    cp "$SRC_PUBLIC/$file" "$target_public/$file"
  done
  UPDATED=$((UPDATED + 1))
}

restore_conversation_if_missing

if [ -d "$ROOT/.conversation/public" ]; then
  copy_into_target "$ROOT/.conversation/public"
fi

if [ -d "$ROOT/artifacts/api-server/genesis/public" ]; then
  copy_into_target "$ROOT/artifacts/api-server/genesis/public"
fi

if [ "$UPDATED" -lt 1 ]; then
  echo "ERROR: No compatible GENESIS public directory was found."
  exit 1
fi

VERIFIED=0
for target in "$ROOT/.conversation/public" "$ROOT/artifacts/api-server/genesis/public"; do
  if [ -f "$target/index.html" ] && grep -q 'GENESIS_SINGLE_SCREEN_V31' "$target/index.html"; then
    VERIFIED=$((VERIFIED + 1))
  fi
done

if [ "$VERIFIED" -lt 1 ]; then
  echo "ERROR: Installation verification failed."
  exit 1
fi

echo "GENESIS SINGLE SCREEN v3.1 installation verification: PASS"
echo "Updated copies: $UPDATED"
echo "Backup: $BACKUP_ROOT"
echo "No server restart was performed."
