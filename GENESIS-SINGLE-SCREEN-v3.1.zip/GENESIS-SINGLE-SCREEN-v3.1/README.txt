GENESIS SINGLE SCREEN v3.1

What changed:
- keeps the single-screen architecture
- larger central reactor / graph
- tighter top section
- metrics moved closer to center
- cleaner bottom panels
- no top header
- no auto server restart

Install from Replit Shell (workspace already open):
rm -rf /tmp/genesis-v31 && mkdir -p /tmp/genesis-v31 && unzip -o GENESIS-SINGLE-SCREEN-v3.1.zip -d /tmp/genesis-v31 && bash /tmp/genesis-v31/GENESIS-SINGLE-SCREEN-v3.1/install.sh

Expected final lines:
GENESIS SINGLE SCREEN v3.1 installation verification: PASS
Updated copies: 2
No server restart was performed.
