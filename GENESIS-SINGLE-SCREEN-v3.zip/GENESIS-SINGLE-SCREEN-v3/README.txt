GENESIS SINGLE SCREEN v3

What changes:
- One-screen / no-scroll layout
- No top header
- Central 3D burn engine graphic
- Four compact live metric blocks around the engine
- Compact Trade > Fees > Buy > Burn rail
- Protocol + 100% rule + transparency fit on the same screen
- Mobile-first iPhone layout
- Completely replaces previous v1/v2 layout CSS to avoid style conflicts

What does NOT change:
- config.js
- server.js
- package.json
- token data / business logic
- Replit workflow / port / restart behavior

Installer never restarts the server.
