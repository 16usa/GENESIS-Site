#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
LATEST="$(find "$ROOT/.genesis-backups" -maxdepth 1 -type d -name 'GENESIS-SINGLE-SCREEN-v3-*' 2>/dev/null | sort | tail -n 1)"
if [ -z "$LATEST" ]; then
  echo "No GENESIS SINGLE SCREEN v3 backup found." >&2
  exit 1
fi
for TARGET in "$ROOT/.conversation" "$ROOT/artifacts/api-server/genesis"; do
  [ -d "$TARGET/public" ] || continue
  SAFE_NAME="$(printf '%s' "$TARGET" | sed "s#^$ROOT/##; s#[/.]#_#g")"
  SRC="$LATEST/$SAFE_NAME"
  [ -d "$SRC" ] || continue
  for FILE in index.html styles.css app.js; do
    [ -f "$SRC/$FILE" ] && cp -a "$SRC/$FILE" "$TARGET/public/$FILE"
  done
done
echo "GENESIS SINGLE SCREEN v3 rollback complete."
echo "No server restart was performed."
