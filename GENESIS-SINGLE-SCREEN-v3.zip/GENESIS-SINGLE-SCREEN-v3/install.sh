#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC="$HERE/public"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/.genesis-backups/GENESIS-SINGLE-SCREEN-v3-$STAMP"
UPDATED=0

PROD="$ROOT/artifacts/api-server/genesis"
DEV="$ROOT/.conversation"

# If Replit's live .conversation copy is absent but the production copy exists,
# reconstruct it first. This only copies files; it does not start or restart anything.
if [ ! -d "$DEV" ] && [ -d "$PROD" ]; then
  cp -a "$PROD" "$DEV"
fi

for TARGET in "$DEV" "$PROD"; do
  if [ ! -d "$TARGET/public" ]; then
    continue
  fi

  SAFE_NAME="$(printf '%s' "$TARGET" | sed "s#^$ROOT/##; s#[/.]#_#g")"
  DEST_BACKUP="$BACKUP/$SAFE_NAME"
  mkdir -p "$DEST_BACKUP"

  for FILE in index.html styles.css app.js; do
    if [ -f "$TARGET/public/$FILE" ]; then
      cp -a "$TARGET/public/$FILE" "$DEST_BACKUP/$FILE"
    fi
    cp -a "$SRC/$FILE" "$TARGET/public/$FILE"
  done

  UPDATED=$((UPDATED + 1))
done

if [ "$UPDATED" -eq 0 ]; then
  echo "GENESIS v3 install failed: no GENESIS public directory found." >&2
  exit 1
fi

PASS=1
for TARGET in "$DEV" "$PROD"; do
  if [ ! -d "$TARGET/public" ]; then
    continue
  fi
  grep -q 'GENESIS_SINGLE_SCREEN_V3' "$TARGET/public/index.html" || PASS=0
  grep -q 'GENESIS_SINGLE_SCREEN_V3' "$TARGET/public/app.js" || PASS=0
  grep -q 'overflow:hidden' "$TARGET/public/styles.css" || PASS=0
done

if [ "$PASS" -ne 1 ]; then
  echo "GENESIS SINGLE SCREEN v3 installation verification: FAIL" >&2
  exit 1
fi

echo "GENESIS SINGLE SCREEN v3 installation verification: PASS"
echo "Updated copies: $UPDATED"
echo "Backup: $BACKUP"
echo "No server restart was performed."
